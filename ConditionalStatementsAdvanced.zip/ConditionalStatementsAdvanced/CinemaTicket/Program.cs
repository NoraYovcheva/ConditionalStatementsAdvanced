﻿using System;

namespace CinemaTicket
{
    class Program
    {
        static void Main(string[] args)
        {
            string day = Console.ReadLine();
            int price = 0;

            if (day == "Monday" || day == "Tuesday" || day == "Friday")
            {
                Console.WriteLine("12");
            }
            else if (day == "Wednesday" || day == "Thursday")
            {
                Console.WriteLine("14");
            }
            else
            {
                Console.WriteLine("16");
            }
            

            //switch (day)
            //{
            //    case "Monday":
            //    case "Tuesday":
            //    case "Friday":
            //        price = 12;
            //        break;

            //    case "Wednesday":
            //    case "Thursday":
            //        price = 14;
            //        break;

            //    case "Satarday":
            //    case "Sunday":
            //        price = 16;
            //        break;
            //}

            //Console.WriteLine(price);

        }
    }

}
   
