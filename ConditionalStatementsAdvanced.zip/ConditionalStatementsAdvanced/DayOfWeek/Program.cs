﻿using System;

namespace DayOfWeek
{
    class Program
    {
        static void Main(string[] args)
        {
            int dayOfWeek = int.Parse(Console.ReadLine());

            //if (dayOfWeek==1)
            //{
            //    Console.WriteLine("Monday");
            //}
            //else if (dayOfWeek==2)
            //{
            //    Console.WriteLine("Tuesday");
            //}
            //else if (dayOfWeek==3)
            //{
            //    Console.WriteLine("Wednesday");
            //}
            //else
            //{
            //    Console.WriteLine("Wrong");
            //}
            string result = "";
            switch (dayOfWeek)
            {
                case 1:
                    result = "Monday";
                    break;
                case 2:
                    result="Tuesday";
                    break;
                case 3:
                    result="Wednesday";
                    break;
                case 4:
                    result="Thursday";
                    break; 
                case 5:
                    result="Friday";
                    break;
                case 6:
                    result="Saturday";
                    break;
                case 7:
                    result="Sunday";
                    break;

                default:
                    result="Error";
                    break;
            }
            Console.WriteLine(result);

        }
    }
}
