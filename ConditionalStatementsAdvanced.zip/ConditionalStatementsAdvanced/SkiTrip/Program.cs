﻿using System;

namespace SkiTrip
{
    class Program
    {
        static void Main(string[] args)
        {
            //•	Първи ред -дни за престой -цяло число в интервала[0...365]
            int daysOfRest = int.Parse(Console.ReadLine());
            //•	Втори ред -вид помещение - "room for one person", "apartment" или "president apartment"
            string tipeOfRoom = Console.ReadLine();
            //•	Трети ред -оценка - "positive"  или "negative"
            string vote = Console.ReadLine();

            double roomPrice = 0;
            double totalPrice = 0;
            double discount = 0;


            switch (tipeOfRoom)
            {
                case "room for one person":
                    roomPrice = 18.00;
                    break;
                case "apartment":
                    roomPrice = 25.00;
                    if (daysOfRest < 10)
                    {
                        discount = 30;
                    }
                    else if (10 <= daysOfRest && daysOfRest <= 15)
                    {
                        discount = 35;
                    }
                    else if (daysOfRest > 15)
                    {
                        discount = 50;
                    }
                    break;

                case "president apartment":
                    roomPrice = 35.00;
                    if (daysOfRest < 10)
                    {
                        discount = 10;
                    }
                    else if (10 <= daysOfRest && daysOfRest <= 15)
                    {
                        discount = 15;
                    }
                    else if (daysOfRest > 15)
                    {
                        discount = 20;
                    }
                    break;
            }
            if (daysOfRest <= 1)
            {
                totalPrice = 0;
            }
            else
            {
                totalPrice = (daysOfRest - 1) * roomPrice;

                totalPrice = totalPrice - (totalPrice * discount / 100);

                if (vote == "positive")
                {
                    totalPrice *= 1.25;
                    //totalPrice = totalPrace * 1.25;
                }
                else
                {
                    totalPrice *= 0.9;
                }
            }

            Console.WriteLine($"{totalPrice:f2}");


        }
    }
}
