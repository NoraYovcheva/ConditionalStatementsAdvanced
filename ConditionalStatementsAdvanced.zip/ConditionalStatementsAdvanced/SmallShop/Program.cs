﻿using System;

namespace SmallShop
{
    class Program
    {
        static void Main(string[] args)
        {
            string productName = Console.ReadLine();
            string town = Console.ReadLine();
            double count = double.Parse(Console.ReadLine());
            double price = 0;
            if (town == "Sofia")
            {
                if (productName == "coffee")
                {
                    Console.WriteLine(0.50 * count);
                }
                if (productName == "water")
                {
                    Console.WriteLine(0.80 * count);
                }
                if (productName == "beer")
                {
                    Console.WriteLine(1.20 * count);
                }
                if (productName == "sweets")
                {
                    Console.WriteLine(1.45 * count);
                }
                if (productName == "peanuts")
                {
                    Console.WriteLine(1.60 * count);
                }
            }
            else if (town == "Plovdiv")
            {
                if (productName == "coffee")
                {
                    Console.WriteLine(0.40 * count);
                }
                if (productName == "water")
                {
                    Console.WriteLine(0.70 * count);
                }
                if (productName == "beer")
                {
                    Console.WriteLine(1.15 * count);
                }
                if (productName == "sweets")
                {
                    Console.WriteLine(1.30 * count);
                }
                if (productName == "peanuts")
                {
                    Console.WriteLine(1.50 * count);
                }
            }
            else if (town=="Varna")
                {
                if (productName == "coffee")
                {
                    Console.WriteLine(0.45 * count);
                }
                if (productName == "water")
                {
                    Console.WriteLine(0.70 * count);
                }
                if (productName == "beer")
                {
                    Console.WriteLine(1.10 * count);
                }
                if (productName == "sweets")
                {
                    Console.WriteLine(1.35 * count);
                }
                if (productName == "peanuts")
                {
                    Console.WriteLine(1.55 * count);
                }
            }
           
        }
    }
}
